import UIKit
import ARKit
import  Photos
import SceneKit

class ViewController: UIViewController {
    let imagePickerController = UIImagePickerController()

    
    @IBOutlet weak var tableView: UITableView!
    
    var selectedImage = UIImage()
    @IBOutlet var sceneView: ARSCNView!
    
    @IBOutlet weak var scaleLabel: UILabel!
    @IBOutlet weak var slider: UISlider!
    @IBOutlet weak var colorBtn: UIButton!
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet var leftSwipeBtn: UISwipeGestureRecognizer!
    @IBOutlet weak var scView: UIView!
    @IBOutlet weak var drawBtn: UIBarButtonItem!
    
    @IBOutlet weak var scaleLabel2: UILabel!
    @IBOutlet weak var TexBtn: UIBarButtonItem!
    
    @IBOutlet weak var sc2: UIScrollView!
    @IBOutlet weak var pageControll: UIPageControl!
    @IBOutlet weak var slider2: UISlider!
  
    
    @IBOutlet var hihyouziBtn: UITapGestureRecognizer!
    @IBOutlet weak var addTextBtn: UITextField!
    
    @IBOutlet weak var maruBtn: UIButton!
    @IBOutlet weak var sikakuBtn: UIButton!
    @IBOutlet weak var katatiView: UIView!
    @IBOutlet weak var scaleBtn: UIButton!
    @IBOutlet weak var toolBar: UIToolbar!
    
    @IBOutlet weak var imageBtn: UIButton!
    @IBOutlet var ImageRightBtn: UISwipeGestureRecognizer!
   
    @IBOutlet weak var setumeiView: UIView!
    @IBOutlet weak var sc: UIScrollView!
    @IBOutlet var objDelBtn: UILongPressGestureRecognizer!
    @IBOutlet var addImageBtn: UITapGestureRecognizer!
    @IBOutlet var drawingBtn: UIPanGestureRecognizer!
   
    @IBOutlet weak var kaitenBtn: UIButton!
    
    struct Photo {
        var imageName:String
        var title:String
    }
    let photoList = [
        Photo(imageName: "rokuga1", title: "録画方法 part1" ),
        Photo(imageName: "rokuga2", title: "録画方法 part2" ),
        Photo(imageName: "rokuga3", title: "録画方法 part3" ),
        Photo(imageName: "rokuga4", title: "録画方法 part4" ),
        Photo(imageName: "draw1", title: "文字を描く" ),
        Photo(imageName: "draw2", title: "文字を消す" ),
        Photo(imageName: "tex1", title: "テキストの追加 part1" ),
        Photo(imageName: "tex2", title: "テキストの追加 part2" ),
        Photo(imageName: "tex3", title: "テキストの追加 part3" ),
        Photo(imageName: "color1", title: "色の変更" ),
        Photo(imageName: "font1", title: "フォントの変更"),
        Photo(imageName: "image1", title: "写真を追加　part1"),
        Photo(imageName: "image2", title: "写真を追加　part2"),
        Photo(imageName: "image3", title: "写真を追加　part3"),
        Photo(imageName: "delete1", title: "写真とテキストを消す　part1"),
        Photo(imageName: "delete2", title: "写真とテキストを消す　part2"),
        Photo(imageName: "scale1", title: "大きさの変更　part1"),
        Photo(imageName: "scale2", title: "大きさの変更　part2"),
        Photo(imageName: "swipe1", title: "写真とテキストを回転　part1"),
        Photo(imageName: "swipe2", title: "写真とテキストを回転　part2"),
        Photo(imageName: "swipe3", title: "写真とテキストを回転　part3"),
        Photo(imageName: "swipe4", title: "写真とテキストを回転　part4"),
        Photo(imageName: "hihyouzi1", title: "非表示モード"),
        Photo(imageName: "reset1", title: "認識が上手くいかない時")
    ]
    var vc = UIView()
    var vc2 = UIView()
    var text = String()
    var node = SCNNode()
    var scale:CGFloat = 0.003
    var photoScale:CGFloat = 0.3
    var temaePhoto:CGFloat = -0.5
    var temaeMozi:CGFloat = -0.4
    var hihyouziNumber = 0
    var position = SCNVector3()
    var drawingNode = SCNNode()
    var sliderNumber = 0
    var selectedKatachi = 0
    let keshigomuImage = UIImage(named: "keshigomu")
    let drawImage = UIImage(named: "Dooble")
    let AlbumImage = UIImage(named: "Album")
    var tagNumber = 0
    var playerView:AVPlayer!
    var textPlayer:AVPlayer!
    let setumeiArray = ["録画方法","文字の書き方と消し方","テキストの追加","色の変更","フォントの変更","写真の追加","写真とテキストを消す","大きさの変更","写真とテキストを回転","非表示モード","認識が上手くいかない時"]
    var dougaName = String()
    let selectedColor = [UIColor.white, UIColor.black, UIColor.lightGray, UIColor.gray, UIColor.darkGray, UIColor.brown, UIColor.blue, UIColor.cyan,UIColor.green, UIColor.magenta, UIColor.orange, UIColor.purple, UIColor.red, UIColor.yellow ]
    
    let defaultConfiguration: ARWorldTrackingConfiguration = {
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = .horizontal
        configuration.environmentTexturing = .automatic
        return configuration
    }()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        sceneView.delegate = self
        sceneView.debugOptions = [ARSCNDebugOptions.showFeaturePoints]
        addTextBtn.delegate = self
        drawBtn.tintColor = UIColor.blue
        TexBtn.tintColor = UIColor.blue
        addTextBtn.isHidden = true
        colorBtn.layer.cornerRadius = colorBtn.frame.height/2
        colorBtn.layer.masksToBounds = true
        maruBtn.layer.cornerRadius =
            maruBtn.frame.height/2
        maruBtn.layer.masksToBounds = true
        ImageRightBtn.isEnabled = false
        scView.isHidden = true
        sc.backgroundColor = UIColor.clear
        vc.frame = CGRect(x: 0, y: 0, width: 700, height: 50)
        slider.isHidden = true
        scaleLabel.isHidden = true
        slider2.isHidden = true
        scaleLabel2.isHidden = true
        scaleLabel.text = "大きさ"
        scaleLabel2.text = "手前からの距離"
        leftSwipeBtn.isEnabled = false
        katatiView.isHidden = true
        tableView.delegate = self
        tableView.dataSource = self
        tableView.isHidden = true
        setumeiView.isHidden = true
        sc2.delegate = self
        pageControll.isHidden = true













            
        

    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        sceneView.session.run(defaultConfiguration)
        
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        sceneView.session.pause()
    }
    func createBallLine() -> SCNNode{
        
        var node: SCNNode!
        let ball = SCNSphere(radius: scale)
        ball.firstMaterial?.diffuse.contents = colorBtn.backgroundColor
        node = SCNNode(geometry: ball)
        
        return node
    }
    func createBoxLine() -> SCNNode {
        var node:SCNNode!
        let box = SCNBox(width: scale, height: scale, length: scale, chamferRadius: 0)
        box.firstMaterial?.diffuse.contents = colorBtn.backgroundColor
        node = SCNNode(geometry: box)
        return node
    }
    
    @IBAction func dragDooble(_ sender: UIPanGestureRecognizer) {
        if drawBtn.tintColor == UIColor.blue {
            if selectedKatachi == 0 {
        let lineNode = createBallLine()
        
        drawingNode = lineNode
        //node = lineNode
            } else if selectedKatachi == 1 {
                let lineNode = createBoxLine()
                drawingNode = lineNode
            }
        
        drawingNode.name = "line"
        //drawingNode?.name = "line"
            let infrontCamera = SCNVector3Make(0, 0, Float(temaeMozi))
        
        guard  let cameraNode = sceneView.pointOfView else {
            return
        }
        let pointInworld  =  cameraNode.convertPosition(infrontCamera, to: nil)
        var screenPosition = sceneView.projectPoint(pointInworld)
        
        guard let location: CGPoint = sender.location(in: sceneView) else {
            return
        }
        screenPosition.x = Float(location.x)
        screenPosition.y = Float(location.y)
        
        let finalposition = sceneView.unprojectPoint(screenPosition)
        
        drawingNode.position = finalposition
        
        
        
        
        sceneView.scene.rootNode.addChildNode(drawingNode)
        } else if drawBtn.tintColor == UIColor.red {
            let location = sender.location(in: sceneView)
            let hitTest = sceneView.hitTest(location)
            if let result = hitTest.first {
                if result.node.name == "line" {
                    result.node.removeFromParentNode()
                }
            }
        }
        
    }

    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }

    
    
    @IBAction func selectedImage(_ sender: Any) {
        imagePicker()
    }

    @IBAction func tapKaiten(_ sender: Any) {
        if ImageRightBtn.isEnabled == false {
            kaitenBtn.backgroundColor = UIColor.green
            ImageRightBtn.isEnabled = true
            leftSwipeBtn.isEnabled = true
            drawingBtn.isEnabled = false
        } else {
            kaitenBtn.backgroundColor = UIColor.white
            drawingBtn.isEnabled = true
            ImageRightBtn.isEnabled = false
            leftSwipeBtn.isEnabled = false
        }
    }
    
    @IBAction func tapDraw(_ sender: UIBarButtonItem){
        if drawBtn.tintColor == UIColor.red {
           drawBtn.tintColor = UIColor.blue
            
        } else if drawBtn.tintColor == UIColor.blue {
             drawBtn.tintColor = UIColor.red
           
        }
    }
    
    private func imagePicker() {
        if UIImagePickerController.isSourceTypeAvailable(.photoLibrary) {
            let pickerView = UIImagePickerController()
            pickerView.sourceType = .photoLibrary
            pickerView.delegate = self
            pickerView.modalPresentationStyle = .overFullScreen
            self.present(pickerView, animated: true, completion: nil)
        }
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let image = (info[.originalImage] as? UIImage)  {
            imageView.image = image
            self.selectedImage = image
        }
        picker.dismiss(animated: true, completion: nil)
    }
    
    private func createPhotoNode(_ image:UIImage, position: SCNVector3) -> SCNNode {
        let node = SCNNode()
        //let scale:CGFloat = 0.3
        let geometry = SCNPlane(width: image.size.width * photoScale/image.size.height, height: photoScale)
        geometry.firstMaterial?.diffuse.contents = image
        node.name = "image"
        node.geometry = geometry
        node.position = position
        return node
    }
   
    
    @IBAction func rotateImage(_ sender: UISwipeGestureRecognizer) {
        let location = sender.location(in: sceneView)
        let hittTest = sceneView.hitTest(location)
        if let result = hittTest.first {
            guard let cameraNode = sceneView.pointOfView else {
                return
            }
            if result.node.name == "image" {
                guard let cameraNode = sceneView.pointOfView else {
                    return
                }
                result.node.eulerAngles = cameraNode.eulerAngles
                result.node.rotation = SCNVector4(0,0,1,-0.25 * .pi)
                result.node.name = "image2"
            } else if result.node.name == "image2" {
                result.node.eulerAngles = cameraNode.eulerAngles
                result.node.rotation = SCNVector4(0,0,1,-0.5 * .pi)
                result.node.name = "image3"
            } else if result.node.name == "image3" {
                result.node.eulerAngles = cameraNode.eulerAngles
                result.node.rotation = SCNVector4(0,0,1,-0.75 * .pi)
                result.node.name = "image4"
            } else if result.node.name == "image4" {
                result.node.eulerAngles = cameraNode.eulerAngles
                result.node.rotation = SCNVector4(0,0,1,-1.0 * .pi)
                result.node.name = "image5"
            } else if result.node.name == "image5" {
                result.node.eulerAngles = cameraNode.eulerAngles
                result.node.rotation = SCNVector4(0,0,1,0.75 * .pi)
                result.node.name = "image6"
            } else if result.node.name == "image6" {
                result.node.eulerAngles = cameraNode.eulerAngles
                result.node.rotation = SCNVector4(0,0,1,0.5 * .pi)
                result.node.name = "image7"
            } else if result.node.name == "image7" {
                result.node.eulerAngles = cameraNode.eulerAngles
                result.node.rotation = SCNVector4(0,0,1,0.25 * .pi)
                result.node.name = "image8"
            } else if result.node.name == "image8" {
                result.node.eulerAngles = cameraNode.eulerAngles
                result.node.rotation = cameraNode.rotation
                result.node.name = "image"

            }
            
        }
    }
    
    @IBAction func rotateLeft(_ sender: UISwipeGestureRecognizer) {
        let location = sender.location(in: sceneView)
        let hittTest = sceneView.hitTest(location)
        if let result = hittTest.first {
            guard let cameraNode = sceneView.pointOfView else {
                return
            }
            if result.node.name == "image" {
                result.node.eulerAngles = cameraNode.eulerAngles
                result.node.rotation = SCNVector4(0,0,1,0.25 * .pi)
                result.node.name = "image8"
            } else if result.node.name == "image8" {
                result.node.eulerAngles = cameraNode.eulerAngles
                result.node.rotation = SCNVector4(0,0,1,0.5 * .pi)
                result.node.name = "image7"
            } else if result.node.name == "image7" {
                result.node.eulerAngles = cameraNode.eulerAngles
                result.node.rotation = SCNVector4(0,0,1,0.75 * .pi)
                result.node.name = "image6"
            } else if result.node.name == "image6" {
                result.node.eulerAngles = cameraNode.eulerAngles
                result.node.rotation = SCNVector4(0,0,1,-1.0 * .pi)
                result.node.name = "image5"
            } else if result.node.name == "image5" {
                result.node.eulerAngles = cameraNode.eulerAngles
                result.node.rotation = SCNVector4(0,0,1,-0.75 * .pi)
                result.node.name = "image4"
            } else if result.node.name == "image4" {
                result.node.eulerAngles = cameraNode.eulerAngles
                result.node.rotation = SCNVector4(0,0,1,-0.5 * .pi)
                result.node.name = "image3"
            } else if result.node.name == "image3" {
                result.node.eulerAngles = cameraNode.eulerAngles
                result.node.rotation = SCNVector4(0,0,1,-0.25 * .pi)
                result.node.name = "image2"
            } else if result.node.name == "image2" {
                result.node.eulerAngles = cameraNode.eulerAngles
                result.node.rotation = cameraNode.rotation
                result.node.name = "image"
                
            }
            
        }
    }
    @IBAction func addImage(_ sender: UITapGestureRecognizer) {
        addImageBtn.require(toFail: hihyouziBtn)
        if setumeiView.isHidden == false {
            setumeiView.isHidden = true
            pageControll.isHidden = true
        } else if tableView.isHidden == false && setumeiView.isHidden == true {
            tableView.isHidden = true
        }
       
        else if self.text != "" {
            let textGeometory = SCNText(string: self.text, extrusionDepth: 10)
            textGeometory.firstMaterial?.diffuse.contents = colorBtn.backgroundColor
            
            if let camera = sceneView.pointOfView {
                let position = SCNVector3(0,0,temaeMozi)
                let convertedPosition = camera.convertPosition(position, to: nil)
                let textnode = SCNNode(geometry: textGeometory)
                textnode.name = "image"
                var screenPosition = sceneView.projectPoint(convertedPosition)
                
                guard let location: CGPoint = sender.location(in: sceneView) else {
                    return
                }
                screenPosition.x = Float(location.x)
                screenPosition.y = Float(location.y)
                
                let finalposition = sceneView.unprojectPoint(screenPosition)
                textnode.scale = SCNVector3(scale, scale, scale)
                textnode.position = finalposition
                textnode.eulerAngles = camera.eulerAngles
                textnode.rotation = camera.rotation
                
                sceneView.scene.rootNode.addChildNode(textnode)
            }
            view.endEditing(true)

        } else if imageView.image != AlbumImage {
            if addTextBtn.isHidden == true {
            if let camera = sceneView.pointOfView {
            // カメラから見て50cm先の座標
                let position = SCNVector3(x: 0, y: 0, z: Float(temaePhoto))
            // 世界座標系に変換
            let convertedPosition = camera.convertPosition(position, to: nil)
            let node = createPhotoNode(self.selectedImage, position: convertedPosition)
            var screenPosition = sceneView.projectPoint(convertedPosition)
            
            let location: CGPoint = sender.location(in: sceneView)
            screenPosition.x = Float(location.x)
            screenPosition.y = Float(location.y)
            
            let finalposition = sceneView.unprojectPoint(screenPosition)
            node.position = finalposition
            
            
            node.eulerAngles = camera.eulerAngles
            node.rotation = camera.rotation
            
            self.sceneView.scene.rootNode.addChildNode(node)
                }
        }
     }
    }
    
    @IBAction func objDelete(_ sender: UILongPressGestureRecognizer) {
        if sender.state == .began {
            let location = sender.location(in: sceneView)
            let hitTest = sceneView.hitTest(location)
            if let result = hitTest.first {
                if result.node.name == "image" {
                    result.node.removeFromParentNode()
                } else if result.node.name == "image2" {
                    result.node.removeFromParentNode()
                } else if result.node.name == "image3" {
                    result.node.removeFromParentNode()
                } else {
                    result.node.removeFromParentNode()
                }
            }
        }

    }
    
    
    @IBAction func addText(_ sender: Any) {
        if TexBtn.tintColor == UIColor.blue {
            TexBtn.tintColor = UIColor.black
            addTextBtn.text = ""
            addTextBtn.isHidden = false
        } else if TexBtn.tintColor == UIColor.black {
            TexBtn.tintColor = UIColor.blue
            self.text = ""
            addTextBtn.isHidden = true
        }
    }
    @IBAction func tapHihyouzi(_ sender: UITapGestureRecognizer) {
        if hihyouziNumber == 0 {
            toolBar.alpha = 0
            imageView.alpha = 0
            imageBtn.alpha = 0
            colorBtn.alpha = 0
            kaitenBtn.alpha = 0
            addTextBtn.alpha = 0
            scaleBtn.alpha = 0
            slider.alpha = 0
            scaleLabel.alpha = 0
            slider2.alpha = 0
            scaleLabel2.alpha = 0
            hihyouziNumber = 1
        } else if hihyouziNumber == 1 {
            toolBar.alpha = 1
            imageView.alpha = 1
            imageBtn.alpha = 1
            colorBtn.alpha = 1
            kaitenBtn.alpha = 1
            addTextBtn.alpha = 1
            scaleBtn.alpha = 1
            slider.alpha = 1
            scaleLabel.alpha = 1
            slider2.alpha = 1
            scaleLabel2.alpha = 1
            hihyouziNumber = 0
        }
    }
    
    @IBAction func changeColor(_ sender: Any) {
        scView.isHidden = false
        katatiView.isHidden = false
        for i in 0..<selectedColor.count {
            let button:UIButton = UIButton()
            button.frame = CGRect(x: (i*50), y: 0, width: 50, height: 50)
            button.layer.cornerRadius = colorBtn.frame.height/2
            button.layer.masksToBounds = true
            button.backgroundColor = selectedColor[i]
            button.tag = i
            button.addTarget(self, action: #selector(buttonTap), for: .touchUpInside)
            vc.addSubview(button)
        }
        sc.addSubview(vc)
        sc.contentSize = vc.bounds.size

    }
    @objc func buttonTap(sender:UIButton){
        
        if sender.tag == 0{
            
            colorBtn.backgroundColor = selectedColor[0]
            maruBtn.backgroundColor = selectedColor[0]
            sikakuBtn.backgroundColor = selectedColor[0]
        }else if sender.tag == 1{
            
            colorBtn.backgroundColor = selectedColor[1]
            maruBtn.backgroundColor = selectedColor[1]
            sikakuBtn.backgroundColor = selectedColor[1]

        }else if sender.tag == 2{
            
            colorBtn.backgroundColor = selectedColor[2]
            maruBtn.backgroundColor = selectedColor[2]
            sikakuBtn.backgroundColor = selectedColor[2]

        }else if sender.tag == 3{
            
           colorBtn.backgroundColor = selectedColor[3]
            maruBtn.backgroundColor = selectedColor[3]
            sikakuBtn.backgroundColor = selectedColor[3]

        }else if sender.tag == 4{
            
            colorBtn.backgroundColor = selectedColor[4]
            maruBtn.backgroundColor = selectedColor[4]
            sikakuBtn.backgroundColor = selectedColor[4]

        }else if sender.tag == 5{
            
            colorBtn.backgroundColor = selectedColor[5]
            maruBtn.backgroundColor = selectedColor[5]
            sikakuBtn.backgroundColor = selectedColor[5]

        }else if sender.tag == 6{
            colorBtn.backgroundColor = selectedColor[6]
            maruBtn.backgroundColor = selectedColor[6]
            sikakuBtn.backgroundColor = selectedColor[6]

        }else if sender.tag == 7{
            colorBtn.backgroundColor = selectedColor[7]
            maruBtn.backgroundColor = selectedColor[7]
            sikakuBtn.backgroundColor = selectedColor[7]

        }else if sender.tag == 8{
            colorBtn.backgroundColor = selectedColor[8]
            maruBtn.backgroundColor = selectedColor[8]
            sikakuBtn.backgroundColor = selectedColor[8]

        }else if sender.tag == 9{
            colorBtn.backgroundColor = selectedColor[9]
            maruBtn.backgroundColor = selectedColor[9]
            sikakuBtn.backgroundColor = selectedColor[9]

        }else if sender.tag == 10{
            colorBtn.backgroundColor = selectedColor[10]
            maruBtn.backgroundColor = selectedColor[10]
            sikakuBtn.backgroundColor = selectedColor[10]

        }else if sender.tag == 11{
            colorBtn.backgroundColor = selectedColor[11]
            maruBtn.backgroundColor = selectedColor[11]
            sikakuBtn.backgroundColor = selectedColor[11]

        }else if sender.tag == 12{
            colorBtn.backgroundColor = selectedColor[12]
            maruBtn.backgroundColor = selectedColor[12]
            sikakuBtn.backgroundColor = selectedColor[12]

        }else if sender.tag == 13{
            colorBtn.backgroundColor = selectedColor[13]
            maruBtn.backgroundColor = selectedColor[13]
            sikakuBtn.backgroundColor = selectedColor[13]

            
        }else if sender.tag == 14{
            colorBtn.backgroundColor = selectedColor[14]
            maruBtn.backgroundColor = selectedColor[14]
            sikakuBtn.backgroundColor = selectedColor[14]

        }
        scView.isHidden = true
        katatiView.isHidden = true
    }
    
    @IBAction func tapMaru(_ sender: Any) {
        colorBtn.layer.cornerRadius = colorBtn.frame.height/2
        colorBtn.layer.masksToBounds = true
        selectedKatachi = 0
    }
    
    @IBAction func tapSikaku(_ sender: Any) {
        colorBtn.layer.cornerRadius = colorBtn.frame.height
        colorBtn.layer.masksToBounds = true
        selectedKatachi = 1
    }
    
    @IBAction func tapScale(_ sender: Any) {
        if scaleBtn.backgroundColor == UIColor.white {
        let actionSheet = UIAlertController(title: "title", message: "楽しもう", preferredStyle: .actionSheet)
        
        actionSheet.popoverPresentationController?.sourceView = view
        actionSheet.popoverPresentationController?.sourceRect = (sender as AnyObject).frame
        
        actionSheet.addAction(UIAlertAction(title: "テキスト設定", style: .default, handler: { (action) -> Void in
            self.moziScale()
        }))
        actionSheet.addAction(UIAlertAction(title: "写真設定", style: .default, handler: { (action) -> Void in
            self.imageScale()
        }))
            
            actionSheet.addAction(UIAlertAction(title: "操作説明", style: .default, handler: { (action) -> Void in
                self.setumei()
            }))
           
        actionSheet.addAction(UIAlertAction(title: "キャンセル", style: .cancel, handler: nil)
        )
        self.present(actionSheet, animated: true, completion: {
            print("アクションシート表示")
        })
        } else {
            slider.isHidden = true
            scaleLabel.isHidden = true
            slider2.isHidden = true
            scaleLabel2.isHidden = true
            scaleBtn.backgroundColor = UIColor.white
        }
    }
    func imageScale () {
        
        scaleBtn.backgroundColor = UIColor.green
        slider.isHidden = false
        slider2.isHidden = false
        scaleLabel.isHidden = false
        scaleLabel2.isHidden = false
        
    }
    func moziScale () {
        scaleBtn.backgroundColor = UIColor.yellow
        slider2.isHidden = false
        scaleLabel2.isHidden = false
        slider.isHidden = false
        scaleLabel.isHidden = false

    }
    func reset() {
        sceneView.session.run(defaultConfiguration, options: [.resetTracking, .removeExistingAnchors,])

    }
    func setumei(){
        tableView.isHidden = false
    }
   
    @IBAction func changedSlider(_ sender: UISlider) {
        if scaleBtn.backgroundColor == UIColor.yellow {
            slider.minimumValue = 0.001
            slider.maximumValue = 0.01
            scaleLabel.text = "大きさ: \(Double(sender.value * 100))"
            
            scale = CGFloat(sender.value)
        } else {
            slider.minimumValue = 0.1
            slider.maximumValue = 1.2
            scaleLabel.text  = "大きさ:\(Double(sender.value * 100))"
            photoScale = CGFloat(sender.value)
        }
    }
    
    @IBAction func changedSlider2(_ sender: UISlider) {
        if scaleBtn.backgroundColor == UIColor.yellow {
            scaleLabel2.text = "手前からの距離:\(Double(sender.value * 100))cm"
            temaeMozi = CGFloat(sender.value)
        } else {
            scaleLabel2.text = "手前からの距離:\(Double(sender.value * 100))cm"
            temaePhoto = CGFloat(sender.value)
        }
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let textStr = addTextBtn.text! as NSString
        let replacedString = textStr.replacingCharacters(in: range, with: string)
        if replacedString == "" {
            self.text = ""
        } else {
           self.text = replacedString
        }
        return true
    }
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        self.text = ""
        return true
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        view.endEditing(true)
        return false
    }
    
   
   
    @IBAction func refleshTap(_ sender: Any) {
        reset()
    }
    
   
   
    
}
    

extension ViewController: UITableViewDelegate,UITableViewDataSource, ARSCNViewDelegate,UIImagePickerControllerDelegate, UINavigationControllerDelegate,UITextFieldDelegate,UIScrollViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return setumeiArray.count
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        let titleLabel = cell.viewWithTag(1) as! UILabel
        titleLabel.text = setumeiArray[indexPath.row]
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let indexPathRow = tableView.indexPathForSelectedRow {
            tableView.deselectRow(at: indexPathRow, animated: true)
            var imageView = UIImageView()
            var imageView2 = UIImageView()
            var imageView3 = UIImageView()
            var imageView4 = UIImageView()
            self.dougaName = self.setumeiArray[indexPathRow.row]
            self.setumeiView.isHidden = false
            //["録画方法","文字の書き方と消し方","テキストの追加","色の変更","フォントの変更","写真の追加","写真とテキストを消す","大きさの変更","写真とテキストを回転","非表示モード","認識が上手くいかない時"]
            pageControll.isHidden = false
            pageControll.numberOfPages = photoList.count
           let SubView = createCotentsView(contentList: photoList)
            sc2.addSubview(SubView)
            sc2.isPagingEnabled = true
            sc2.contentSize = SubView.frame.size
            if dougaName == "録画方法" {
                sc2.contentOffset = CGPoint(x: 0, y: 0)
                 pageControll.currentPage = 0
            } else if dougaName == "文字の書き方と消し方" {
                sc2.contentOffset = CGPoint(x: 1360, y: 0)
                pageControll.currentPage = 4
            } else if dougaName == "テキストの追加" {
                sc2.contentOffset = CGPoint(x: 1360 + (340*2), y: 0)
                pageControll.currentPage = 6
            } else if dougaName == "色の変更" {
                sc2.contentOffset = CGPoint(x: 1360 + (340*5), y: 0)
                pageControll.currentPage = 9
            } else if dougaName == "フォントの変更" {
                sc2.contentOffset = CGPoint(x: 1360 + (340*6), y: 0)
                pageControll.currentPage = 10
            } else if dougaName == "写真の追加" {
                sc2.contentOffset = CGPoint(x: 1360 + (340*7), y: 0)
                pageControll.currentPage = 11
            } else if dougaName == "写真とテキストを消す" {
                sc2.contentOffset = CGPoint(x: 1360 + (340*10), y: 0)
                pageControll.currentPage = 14
            } else if dougaName == "大きさの変更" {
                sc2.contentOffset = CGPoint(x: 1360 + (340*12), y: 0)
                pageControll.currentPage = 16
            } else if dougaName == "写真とテキストを回転" {
                sc2.contentOffset = CGPoint(x: 1360 + (340*14), y: 0)
                pageControll.currentPage = 18
            } else if dougaName == "非表示モード" {
                sc2.contentOffset = CGPoint(x: 1360 + (340*18), y: 0)
                pageControll.currentPage = 22
            } else if dougaName == "認識が上手くいかない時" {
                sc2.contentOffset = CGPoint(x: 1360 + (340*19), y: 0)
                pageControll.currentPage = 23
            }
            pageControll.pageIndicatorTintColor = UIColor.lightGray
            pageControll.currentPageIndicatorTintColor = UIColor.black
           
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    func createPage(viewRect:CGRect, imageSize:CGSize, item:Photo) ->UIView {
        let pageView = UIView(frame: viewRect)
        let photoView = UIImageView()
        let left = (pageView.frame.width - imageSize.width)/2
        photoView.frame = CGRect(x:left, y:10, width:imageSize.width, height: imageSize.height)
        photoView.contentMode = .scaleToFill
        photoView.image = UIImage(named: item.imageName)
        //ラベルを作り写真タイトル
        let titleFrame = CGRect(x: left, y: photoView.frame.maxY + 10, width: 340, height: 21)
        let titleLabel = UILabel(frame: titleFrame)
        titleLabel.backgroundColor = UIColor.white
        titleLabel.text = item.title
        //写真とタイトルとページビューに追加する
        pageView.addSubview(photoView)
        pageView.addSubview(titleLabel)
        return pageView
    }
    func createCotentsView(contentList:Array<Photo>) -> UIView {
        let contentView = UIView()
        //１ページの幅と高さ
        let pageWidth = self.setumeiView.frame.width
        let pageHeight = sc2.frame.height
        let pageViewRect = CGRect(x: 0, y: 0, width: pageWidth, height: pageHeight)
        //写真のサイズ
        let PhotoSize = CGSize(width: 340, height: 340)
        contentView.frame = CGRect(x: 0, y: 0, width: pageWidth*24, height: pageHeight)
        for i in 0..<contentList.count {
           let contentItem = contentList[i]
            let pageView = createPage(viewRect: pageViewRect, imageSize: PhotoSize, item: contentItem)
            let left = pageViewRect.width * CGFloat(i)
            let xy = CGPoint(x: left, y: 0)
            pageView.frame = CGRect(origin: xy, size: pageViewRect.size)
            contentView.addSubview(pageView)
        }
        return contentView
    }
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let pageNo = Int(sc2.contentOffset.x/sc2.frame.width)
        pageControll.currentPage = pageNo
    }
    
    
    func renderer(_ renderer: SCNSceneRenderer, didAdd node: SCNNode, for anchor: ARAnchor) {
        
    }
   
    
    
}

        
   
    


    
    

    
    


